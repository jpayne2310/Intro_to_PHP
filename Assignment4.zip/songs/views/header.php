<!DOCTYPE html>
    <html lang="en">
    <head ><title>Assignment 3</title></head>
    <?php ob_end_clean(); ?>
    <body>
         <p>Songs
         <?php echo date('h:i a d M y');     //output date and tim
         $sound = 3;
         echo $sound;
         ?></p>