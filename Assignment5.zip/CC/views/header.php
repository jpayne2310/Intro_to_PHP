<!DOCTYPE html>
    <html lang="en">
    <head ><title>Assignment 5</title></head>
    <?php ob_end_clean(); ?>
    <body>
         <p>Credit Card Validation
         <?php echo date('h:i a d M y');     //output date and tim
         ?></p>