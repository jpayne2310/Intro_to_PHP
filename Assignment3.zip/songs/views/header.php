<!DOCTYPE html>
    <html lang="en">
    <head ><title>Assignment 3</title></head>
    <body>
         <p>Songs
         <?php echo date('h:i a d M y');     //output date and time
         ?></p>