<footer>
    <link rel="stylesheet" type="text/css" href="css/strategyblog.css" />
    <div class="footer">
        <div class="hype_b_right">
<a href="https://www.facebook.com/Steam/">
<img class="border" src="images/face.ico" alt="Facebook Icon" style="width:75px;height:75px;"></a>
<a href="https://twitter.com/steam_games?lang=en">
<img class="border" src="images/twitter.ico" alt="Twitter Icon" style="width:75px;height:75px;"></a>
<a href="https://www.youtube.com/user/SteamLog">
<img class="border" src="images/youtube.png" alt="u-tube thumb" style="width:75px;height:75px;"></a>
<p>Copyright &copy;<?php echo date('Y');?> James Payne. All Rights Reserved</p>
</div>
    </div>
</footer>
</div>
</body>
</html>