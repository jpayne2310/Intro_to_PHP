<p>Copyright &copy;<?php echo date('Y');?> James Payne. All Rights Reserved</p>
</body>
</html>