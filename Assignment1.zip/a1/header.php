<!DOCTYPE html>
    <html lang="en">
    <head ><title>Assignment 1</title></head>
    <body>
         <p>Random colors using PHP
         <?php echo date('h:i a d M y');     //output date and time
         ?></p>